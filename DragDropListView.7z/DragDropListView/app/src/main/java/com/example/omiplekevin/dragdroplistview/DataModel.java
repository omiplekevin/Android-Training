package com.example.omiplekevin.dragdroplistview;

/**
 * Created by OMIPLEKEVIN on Jan 02, 2016.
 */
public class DataModel {

    public String name;
    public int age;
    public boolean state;

}
